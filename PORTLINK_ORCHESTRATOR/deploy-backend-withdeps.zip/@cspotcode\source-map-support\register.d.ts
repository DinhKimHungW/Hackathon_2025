// tslint:disable:no-useless-files

// For following usage:
//    import '@cspotcode/source-map-support/register'
// Instead of:
//    import sourceMapSupport from '@cspotcode/source-map-support'
//    sourceMapSupport.install()
