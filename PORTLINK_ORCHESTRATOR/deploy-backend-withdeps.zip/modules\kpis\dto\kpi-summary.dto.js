"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.KPISummaryDto = exports.ScheduleKPIsDto = exports.AssetKPIsDto = exports.TaskKPIsDto = exports.ShipKPIsDto = void 0;
class ShipKPIsDto {
}
exports.ShipKPIsDto = ShipKPIsDto;
class TaskKPIsDto {
}
exports.TaskKPIsDto = TaskKPIsDto;
class AssetKPIsDto {
}
exports.AssetKPIsDto = AssetKPIsDto;
class ScheduleKPIsDto {
}
exports.ScheduleKPIsDto = ScheduleKPIsDto;
class KPISummaryDto {
}
exports.KPISummaryDto = KPISummaryDto;
//# sourceMappingURL=kpi-summary.dto.js.map