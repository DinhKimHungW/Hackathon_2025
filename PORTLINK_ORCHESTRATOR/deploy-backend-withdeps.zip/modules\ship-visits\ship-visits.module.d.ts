export declare class ShipVisitsModule {
}
