export declare class WebSocketModule {
}
