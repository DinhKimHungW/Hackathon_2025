export declare class ChatbotModule {
}
