export declare class EventLogsModule {
}
