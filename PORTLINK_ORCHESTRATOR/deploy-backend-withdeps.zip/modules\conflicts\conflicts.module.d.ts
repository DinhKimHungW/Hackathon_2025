export declare class ConflictsModule {
}
