export declare class KpisModule {
}
