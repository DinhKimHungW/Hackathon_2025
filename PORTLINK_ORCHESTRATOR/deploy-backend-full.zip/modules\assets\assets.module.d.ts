export declare class AssetsModule {
}
