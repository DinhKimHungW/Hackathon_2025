import { TypeOrmModuleOptions } from '@nestjs/typeorm';
declare const _default: (() => TypeOrmModuleOptions) & import("@nestjs/config").ConfigFactoryKeyHost<TypeOrmModuleOptions>;
export default _default;
