export declare class ResolveConflictDto {
    resolutionNotes?: string;
}
