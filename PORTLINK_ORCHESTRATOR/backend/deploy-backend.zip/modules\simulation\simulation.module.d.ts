export declare class SimulationModule {
}
