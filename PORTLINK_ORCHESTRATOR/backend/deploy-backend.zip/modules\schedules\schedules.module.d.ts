export declare class SchedulesModule {
}
