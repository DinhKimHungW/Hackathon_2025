"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScheduleTimelineDataDto = exports.AssetUtilizationDataDto = exports.TaskStatusDataDto = exports.ShipArrivalDataDto = void 0;
class ShipArrivalDataDto {
}
exports.ShipArrivalDataDto = ShipArrivalDataDto;
class TaskStatusDataDto {
}
exports.TaskStatusDataDto = TaskStatusDataDto;
class AssetUtilizationDataDto {
}
exports.AssetUtilizationDataDto = AssetUtilizationDataDto;
class ScheduleTimelineDataDto {
}
exports.ScheduleTimelineDataDto = ScheduleTimelineDataDto;
//# sourceMappingURL=chart-data.dto.js.map